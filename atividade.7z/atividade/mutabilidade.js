
let meuArray = [1, 2, 3];
meuArray[0] = 4;
console.log(meuArray); 

let minhaString = "Olá";

console.log(minhaString); 

