const destinos = [
    { id: 1, nome: 'Paris', precoDiario: 150 },
    { id: 2, nome: 'Nova York', precoDiario: 200 },
    { id: 3, nome: 'Tóquio', precoDiario: 180 }
];

let viagens = [];

exports.listarDestinos = (req, res) => {
    res.status(200).send(destinos);
};

exports.cadastrarDestino = (req, res) => {
    const novoDestino = req.body;
    destinos.push(novoDestino);
    res.status(201).send({ mensagem: 'Destino adicionado!' });
};

exports.listarViagens = (req, res) => {
    res.status(200).send(viagens);
};

exports.cadastrarViagem = (req, res) => {
    const { destinoId, dataInicio, dataFim } = req.body;

    const destino = destinos.find(d => d.id === destinoId);
    
    if (!destino) {
        return res.status(400).send({ mensagem: 'Destino não encontrado!' });
    }

    const dataInicioObj = new Date(dataInicio);
    const dataFimObj = new Date(dataFim);
    const dias = Math.ceil((dataFimObj - dataInicioObj) / (1000 * 60 * 60 * 24));

    if (dias <= 0) {
        return res.status(400).send({ mensagem: 'Data de início deve ser anterior à data de fim!' });
    }

    const custoViagem = dias * destino.precoDiario;
    const viagemId = viagens.length + 1; // Gerar um novo ID para a viagem
    viagens.push({ id: viagemId, destino, dataInicio, dataFim, custoViagem });
    res.status(200).send({ mensagem: `Viagem registrada! Custo total: R$ ${custoViagem}`, viagemId });
};

exports.mostrarViagem = (req, res) => {
    const { viagemId } = req.params;
    const viagem = viagens.find(v => v.id === parseInt(viagemId));

    if (!viagem) {
        return res.status(404).send({ mensagem: 'Viagem não encontrada' });
    }

    res.status(200).send(viagem);
};

exports.calcularCustoTotal = (req, res) => {
    const custoTotal = viagens.reduce((total, viagem) => total + viagem.custoViagem, 0);
    res.status(200).send({ custoTotal });
};
