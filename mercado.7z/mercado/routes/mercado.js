const express = require('express');
const router = express.Router();
const controller = require('../controllers/mercado');

// Rotas de Produtos
router.get('/listarProdutos', controller.listarProdutos);
router.post('/cadastrarProduto', controller.cadastrarProduto);

// Rotas de Clientes
router.get('/listarClientes', controller.listarClientes);
router.post('/cadastrarCliente', controller.cadastrarCliente);

// Rotas de Compras
router.post('/registrarCompra', controller.registrarCompra);
router.get('/mostrarCompra/:compraId', controller.mostrarCompra);
router.get('/mostrarValorTotal', controller.mostrarValorTotal);

module.exports = router;
