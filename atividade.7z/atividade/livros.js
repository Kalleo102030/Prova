function filtrarLivros(livros) {
    return livros
        .filter(livro => livro.autor.length > 5)
        .map(livro => livro.titulo);
}

const livros = [
    { titulo: "A Revolução dos Bichos", autor: "George Orwell" },
    { titulo: "Dom Casmurro", autor: "Machado de Assis" },
    { titulo: "O Morro dos Ventos Uivantes", autor: "Emily Brontë" }
];
console.log(filtrarLivros(livros)); 
