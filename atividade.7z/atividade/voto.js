
function verificarVoto(idade) {
    if (idade >= 18) {
        console.log("A pessoa pode votar.");
        if (idade <= 70) {
            console.log("A votação é obrigatória.");
        } else {
            console.log("A votação não é obrigatória.");
        }
    } else {
        console.log("A pessoa não pode votar.");
    }
}

verificarVoto(20);
