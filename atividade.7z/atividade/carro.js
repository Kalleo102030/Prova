function descreverCarro(carro) {
    return `O carro é um ${carro.modelo} ${carro.ano} ${carro.marca}.`;
}

const carro = { marca: "Toyota", modelo: "Corolla", ano: 2022 };
console.log(descreverCarro(carro)); 
