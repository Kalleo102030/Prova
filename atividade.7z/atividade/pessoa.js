function descreverPessoa(pessoa) {
    return `Nome: ${pessoa.nome}, Idade: ${pessoa.idade}`;
}

const pessoa = { nome: "João", idade: 30 };
console.log(descreverPessoa(pessoa)); 
