const express = require('express');
const router = express.Router();
const controller = require('../controllers/viagem');

// Rotas de Destinos
router.get('/listarDestinos', controller.listarDestinos);
router.post('/cadastrarDestino', controller.cadastrarDestino);

// Rotas de Viagens
router.get('/listarViagens', controller.listarViagens);
router.post('/cadastrarViagem', controller.cadastrarViagem);
router.get('/mostrarViagem/:viagemId', controller.mostrarViagem);
router.get('/calcularCustoTotal', controller.calcularCustoTotal);

module.exports = router;
