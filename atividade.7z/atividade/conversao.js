const numeros = [1, 2, 3, 4, 5];
const strings = numeros.map(num => num.toString());
console.log(strings); 
