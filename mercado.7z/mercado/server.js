const express = require('express')
const port = 3000
const bodyParser = require('body-parser')
const mercadoRoutes = require('./routes/mercado.js')

const app = express()
app.use(bodyParser.json())
app.use('/mercado', mercadoRoutes)

app.listen(port, () => {
    console.log('Servidor rodando!')
})