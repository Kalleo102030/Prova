const produtos = [
    { id: 1, nome: 'Arroz', preco: 20 },
    { id: 2, nome: 'Feijão', preco: 10 },
    { id: 3, nome: 'Macarrão', preco: 10 }
];

const clientes = [
    { id: 1, nome: 'Roberto' },
    { id: 2, nome: 'Leo' },
    { id: 3, nome: 'Jucicleia' }
];

let compras = [];

exports.listarProdutos = (req, res) => {
    res.status(200).send(produtos);
};

exports.cadastrarProduto = (req, res) => {
    const novoProduto = req.body;
    produtos.push(novoProduto);
    res.status(201).send({ mensagem: 'Produto adicionado!' });
};

exports.listarClientes = (req, res) => {
    res.status(200).send(clientes);
};

exports.cadastrarCliente = (req, res) => {
    const novoCliente = req.body;
    clientes.push(novoCliente);
    res.status(201).send({ mensagem: 'Cliente cadastrado!' });
};

exports.registrarCompra = (req, res) => {
    const { clienteId, produtos: produtosList } = req.body;

    const cliente = clientes.find(c => c.id === clienteId);

    if (!cliente) {
        return res.status(400).send({ mensagem: 'Cliente não encontrado!' });
    }

    if (!Array.isArray(produtosList) || produtosList.length === 0) {
        return res.status(400).send({ mensagem: 'Dados de produtos insuficientes!' });
    }

    let valorTotalCompra = 0;
    const compraDetalhes = [];

    for (const item of produtosList) {
        const produto = produtos.find(p => p.id === item.produtoId);
        if (produto) {
            const valorCompra = produto.preco * item.quantidade;
            valorTotalCompra += valorCompra;
            compraDetalhes.push({
                produto,
                quantidade: item.quantidade,
                valorCompra
            });
        } else {
            return res.status(400).send({ mensagem: `Produto com ID ${item.produtoId} não encontrado!` });
        }
    }

    const compraId = compras.length + 1; // Gerar um novo ID para a compra
    compras.push({ id: compraId, cliente, produtos: compraDetalhes, valorTotalCompra });
    res.status(200).send({ mensagem: `Compra registrada! Valor total: R$ ${valorTotalCompra}`, compraId });
};

exports.mostrarCompra = (req, res) => {
    const { compraId } = req.params; // Obtém o compraId da URL
    const compra = compras.find(c => c.id === parseInt(compraId));

    if (!compra) {
        return res.status(404).send({ mensagem: 'Compra não encontrada' });
    }

    res.status(200).send(compra);
};

exports.mostrarValorTotal = (req, res) => {
    let valorTotal = compras.reduce((total, compra) => total + compra.valorTotalCompra, 0);
    res.status(200).send({ valorTotal });
};
