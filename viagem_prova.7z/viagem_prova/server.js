const express = require('express');
const port = 3000;
const bodyParser = require('body-parser');
const viagemRoutes = require('./routes/viagem');

const app = express();

// Configurar o body-parser para lidar com JSON
app.use(bodyParser.json());

// Usar as rotas de viagem
app.use('/viagem', viagemRoutes);

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
