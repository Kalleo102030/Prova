
function soma(num1, num2) {
    return num1 + num2;
}


console.log(soma(5, 3));
