const frutas = ["maçã", "banana", "laranja"];
const frutasMaiusculas = frutas.map(fruta => fruta.toUpperCase());
console.log(frutasMaiusculas); 
