
const sentencas = [
    { texto: "O céu é azul.", proposicao: true },
    { texto: "Abra a porta.", proposicao: false },
    { texto: "2 + 2 = 4.", proposicao: true },
    { texto: "Vamos ao cinema amanhã.", proposicao: false }
];

sentencas.forEach(sentenca => {
    const status = sentenca.proposicao ? "é uma proposição." : "não é uma proposição.";
    console.log(`"${sentenca.texto}" ${status}`);
});
